#!/usr/bin/env bash

# config for work_nodes only 
# kubeadm을 이용해 쿠버네티스 마스터 노드에 접속
# 연결에 필요한 토큰은 기존에 마스터 노드에서 생성한 임의의 토큰을 사용
# 간단하게 구성하기 위해 `--discovery-token-unsafe-skip-ca-verification`으로 인증을 무시하고
# API 서버 주소인 192.168.1.10으로 기보 포트 번호인 6443번 포트에 접속하도록 설정
kubeadm join --token 123456.1234567890123456 \
             --discovery-token-unsafe-skip-ca-verification 192.168.1.10:6443