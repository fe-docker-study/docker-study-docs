#!/usr/bin/env bash

# install packages 
yum install epel-release -y
yum install vim-enhanced -y
# 깃허브 이용을 위해 git을 설치
yum install git -y

# install docker 
# 쿠버네티스를 관리하는 컨테이너를 설치하기 위해 도커를 설치/구동
yum install docker -y && systemctl enable --now docker

# install kubernetes cluster 
yum install kubectl-$1 kubelet-$1 kubeadm-$1 -y
systemctl enable --now kubelet

# git clone _Book_k8sInfra.git 
# 깃에서 코드를 clone하여 실습을 진행할 루트 홈디렉토리(/root)로 옮김
# 배시 스크립트(.sh)를 찾아서 바로 실행 가능한 상태가 되도록 chmod 700으로 설정
if [ $2 = 'Main' ]; then
  git clone https://github.com/sysnet4admin/_Book_k8sInfra.git
  mv /home/vagrant/_Book_k8sInfra $HOME
  find $HOME/_Book_k8sInfra/ -regex ".*\.\(sh\)" -exec chmod 700 {} \;
fi
